import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyCFPwF_OWquXphA8H2lmuLG0SBzFc2WVzM",
  authDomain: "agenda-66e23.firebaseapp.com",
  projectId: "agenda-66e23",
  storageBucket: "agenda-66e23.appspot.com",
  messagingSenderId: "604700905268",
  appId: "1:604700905268:web:5bcaf1d60dd9dff3c65f61"
};

